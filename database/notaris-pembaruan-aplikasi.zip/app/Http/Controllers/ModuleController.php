<?php

namespace App\Http\Controllers;

use App\Support\JobDateRange;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;

class ModuleController extends Controller
{
    public function audit()
    {
        return Inertia::render('Modules/Table', [
            'title' => 'Audit Log',
            'columns' => ['userName', 'activity', 'details', 'ipAddress', 'device', 'createdAt'],
            'rows' => DB::table('activitylog as a')->leftJoin('user as u', function ($join) {
                $join->on(DB::raw('u.id COLLATE utf8mb4_unicode_ci'), '=', DB::raw('a.userId COLLATE utf8mb4_unicode_ci'));
            })->leftJoin('admin as ad', function ($join) {
                $join->on(DB::raw('ad.id COLLATE utf8mb4_unicode_ci'), '=', DB::raw('a.userId COLLATE utf8mb4_unicode_ci'));
            })->select('a.*')->selectRaw('COALESCE(u.fullName, ad.fullName) as userName')->orderByDesc('a.createdAt')->paginate(30),
        ]);
    }

    public function stats(Request $request)
    {
        $range = JobDateRange::fromRequest($request);
        $tables = [
            'badan_hukum' => 'Badan Hukum/Usaha',
            'non_badan_hukum' => 'Non Badan Hukum',
            'ppat' => 'PPAT',
        ];
        $stats = [
            'total' => 0,
            'PENDING' => 0,
            'PROSES' => 0,
            'REVISI' => 0,
            'VERIFIKASI' => 0,
            'SELESAI' => 0,
            'CANCELLED' => 0,
        ];
        $months = collect($range->months())
            ->map(fn ($date) => [
                'key' => $date->format('Y-m'),
                'name' => $date->translatedFormat('M'),
                'year' => $date->format('Y'),
                'total' => 0,
                'completed' => 0,
            ])->keyBy('key');
        $categories = collect();
        $priorities = collect(['LOW', 'MEDIUM', 'HIGH', 'URGENT'])->mapWithKeys(fn ($priority) => [$priority => 0]);
        $deadlines = collect();
        $overdueJobs = collect();
        $recentCompleted = collect();
        $completionDays = collect();
        $thisMonth = 0;
        $previousMonth = 0;

        foreach ($tables as $table => $categoryLabel) {
            $category = [
                'key' => $table,
                'label' => $categoryLabel,
                'total' => 0,
                'completed' => 0,
                'active' => 0,
            ];
            foreach ($range->apply(DB::table($table))->select('status', DB::raw('COUNT(*) total'))->groupBy('status')->get() as $row) {
                $count = (int) $row->total;
                $stats['total'] += $count;
                $key = in_array($row->status, ['REVISI', 'REVISI_PROSES'], true) ? 'REVISI' : $row->status;
                if (array_key_exists($key, $stats)) {
                    $stats[$key] += $count;
                }
                $category['total'] += $count;
                $category['completed'] += $row->status === 'SELESAI' ? $count : 0;
                $category['active'] += ! in_array($row->status, ['SELESAI', 'CANCELLED'], true) ? $count : 0;
            }
            $categories->push($category);

            foreach ($range->apply(DB::table($table))->select('priority', DB::raw('COUNT(*) total'))->groupBy('priority')->get() as $row) {
                if ($priorities->has($row->priority)) {
                    $priorities[$row->priority] += (int) $row->total;
                }
            }

            foreach ($range->apply(DB::table($table))->select('createdAt', 'updatedAt', 'status')->get() as $job) {
                $created = substr((string) $job->createdAt, 0, 7);
                if ($months->has($created)) {
                    $row = $months->get($created);
                    $row['total']++;
                    $months->put($created, $row);
                }
                $updated = substr((string) $job->updatedAt, 0, 7);
                if ($job->status === 'SELESAI' && $months->has($updated)) {
                    $row = $months->get($updated);
                    $row['completed']++;
                    $months->put($updated, $row);
                }
            }

            $thisMonth += DB::table($table)->whereBetween('createdAt', [now()->startOfMonth(), now()->endOfMonth()])->count();
            $previousMonth += DB::table($table)->whereBetween('createdAt', [now()->subMonthNoOverflow()->startOfMonth(), now()->subMonthNoOverflow()->endOfMonth()])->count();

            $baseJobQuery = fn () => $range->apply(DB::table($table.' as j'), 'j.createdAt')
                ->leftJoin('client as c', 'c.id', '=', 'j.clientId')
                ->select('j.id', 'j.trackingCode', 'j.title', 'j.deadline', 'j.status', 'j.priority', 'j.createdAt', 'j.updatedAt', 'c.name as clientName')
                ->selectRaw('? as category, ? as jobType', [$categoryLabel, $table]);

            $deadlines = $deadlines->concat(
                $baseJobQuery()
                    ->whereNotIn('j.status', ['SELESAI', 'CANCELLED'])
                    ->whereBetween('j.deadline', [today(), now()->addDays(7)->endOfDay()])
                    ->get()
            );
            $overdueJobs = $overdueJobs->concat(
                $baseJobQuery()
                    ->whereNotIn('j.status', ['SELESAI', 'CANCELLED'])
                    ->whereNotNull('j.deadline')
                    ->whereDate('j.deadline', '<', today())
                    ->get()
            );
            $recentCompleted = $recentCompleted->concat(
                $baseJobQuery()
                    ->where('j.status', 'SELESAI')
                    ->orderByDesc('j.updatedAt')
                    ->limit(5)
                    ->get()
            );
            foreach ($range->apply(DB::table($table))->where('status', 'SELESAI')->whereNotNull('createdAt')->whereNotNull('updatedAt')->select('createdAt', 'updatedAt')->get() as $job) {
                $completionDays->push(max(0, Carbon::parse($job->createdAt)->diffInDays(Carbon::parse($job->updatedAt))));
            }
        }

        $processing = $stats['PROSES'] + $stats['REVISI'] + $stats['VERIFIKASI'];
        $completionRate = $stats['total'] > 0 ? round(($stats['SELESAI'] / $stats['total']) * 100, 1) : 0;
        $growth = $previousMonth > 0
            ? round((($thisMonth - $previousMonth) / $previousMonth) * 100, 1)
            : ($thisMonth > 0 ? 100 : 0);

        return Inertia::render('Modules/Stats', [
            'filters' => $range->filters(),
            'stats' => [...$stats, 'processing' => $processing],
            'summary' => [
                'active' => $stats['PENDING'] + $processing,
                'completionRate' => $completionRate,
                'overdue' => $overdueJobs->count(),
                'dueSoon' => $deadlines->count(),
                'thisMonth' => $thisMonth,
                'monthlyGrowth' => $growth,
                'averageCompletionDays' => $completionDays->isNotEmpty() ? round($completionDays->average(), 1) : 0,
                'clients' => DB::table('client')->count(),
            ],
            'months' => $months->values(),
            'categories' => $categories,
            'priorities' => $priorities->map(fn ($total, $priority) => ['key' => $priority, 'total' => $total])->values(),
            'statusDistribution' => collect([
                ['key' => 'PENDING', 'label' => 'Pending', 'total' => $stats['PENDING'], 'color' => '#f59e0b'],
                ['key' => 'PROCESSING', 'label' => 'Dalam Proses', 'total' => $processing, 'color' => '#3b82f6'],
                ['key' => 'SELESAI', 'label' => 'Selesai', 'total' => $stats['SELESAI'], 'color' => '#10b981'],
                ['key' => 'CANCELLED', 'label' => 'Dibatalkan', 'total' => $stats['CANCELLED'], 'color' => '#94a3b8'],
            ]),
            'deadlines' => $deadlines->sortBy('deadline')->take(6)->values(),
            'overdueJobs' => $overdueJobs->sortBy('deadline')->take(6)->values(),
            'recentCompleted' => $recentCompleted->sortByDesc('updatedAt')->take(6)->values(),
        ]);
    }

    public function productivity(Request $request)
    {
        $data = $this->productivityData();
        if (! in_array($request->session()->get('auth_user.role'), ['ADMINISTRATOR', 'PIMPINAN'], true)) {
            $id = $request->session()->get('auth_user.source') === 'user' ? $request->session()->get('auth_user.id') : null;
            $data['staff'] = $data['staff']->where('id', $id)->values();
        }

        return Inertia::render('Modules/Productivity', $data);
    }

    private function productivityData(): array
    {
        $staff = DB::table('user')
            ->select('id', 'fullName', 'username', 'role')
            ->whereIn('role', ['STAFFADMIN', 'OB', 'ADMINISTRATOR', 'PIMPINAN'])
            ->get()
            ->keyBy('id')
            ->map(fn ($user) => [
                ...(array) $user,
                'completed' => 0,
                'processing' => 0,
                'totalJobs' => 0,
                'totalTasks' => 0,
                'picTasks' => 0,
                'witnessTasks' => 0,
                'presentDays' => 0,
                'lateDays' => 0,
                'absentDays' => null,
                'workingDays' => null,
                'cancelled' => 0,
                'overdue' => 0,
            ]);

        foreach (['badan_hukum', 'non_badan_hukum', 'ppat'] as $table) {
            foreach (DB::table($table)->whereNotNull('staffId')->select('staffId', 'status', 'deadline')->get() as $job) {
                if ($staff->has($job->staffId)) {
                    $row = $staff[$job->staffId];
                    $row['totalJobs']++;
                    if ($job->status === 'CANCELLED') $row['cancelled']++;
                    if (! in_array($job->status, ['SELESAI', 'CANCELLED'], true) && $job->deadline && Carbon::parse($job->deadline)->lt(today())) $row['overdue']++;
                    $job->status === 'SELESAI' ? $row['completed']++ : ($job->status !== 'CANCELLED' ? $row['processing']++ : 0);
                    $staff[$job->staffId] = $row;
                }
            }
        }

        $taskCounts = DB::table('job_employee_task')
            ->whereIn('userId', $staff->keys())
            ->select('userId', 'taskType')
            ->selectRaw('COUNT(*) as total')
            ->groupBy('userId', 'taskType')
            ->get();
        foreach ($taskCounts as $taskCount) {
            if (! $staff->has($taskCount->userId)) {
                continue;
            }
            $row = $staff[$taskCount->userId];
            $row['totalTasks'] += (int) $taskCount->total;
            if ($taskCount->taskType === 'PIC') {
                $row['picTasks'] += (int) $taskCount->total;
            }
            if ($taskCount->taskType === 'Saksi') {
                $row['witnessTasks'] += (int) $taskCount->total;
            }
            $staff[$taskCount->userId] = $row;
        }

        $today = now()->startOfDay();
        $monthStart = $today->copy()->startOfMonth();
        $profiles = DB::table('staff')
            ->whereIn('userId', $staff->keys())
            ->select('id', 'userId', 'createdAt')
            ->get()
            ->keyBy('userId');
        $attendance = DB::table('attendance')
            ->whereIn('staffId', $profiles->pluck('id'))
            ->whereBetween('date', [$monthStart, $today->copy()->endOfDay()])
            ->get()
            ->groupBy('staffId');

        foreach ($staff as $userId => $row) {
            $profile = $profiles->get($userId);
            if (! $profile) {
                continue;
            }

            $records = $attendance->get($profile->id, collect());
            $presentDays = $records
                ->filter(fn ($record) => ! empty($record->checkIn))
                ->map(fn ($record) => Carbon::parse($record->date)->toDateString())
                ->unique()
                ->count();
            $lateDays = $records
                ->filter(fn ($record) => ! empty($record->checkIn) && Carbon::parse($record->checkIn)->format('H:i:s') > '08:00:00')
                ->map(fn ($record) => Carbon::parse($record->date)->toDateString())
                ->unique()
                ->count();
            $employmentStart = Carbon::parse($profile->createdAt)->startOfDay();
            $periodStart = $employmentStart->greaterThan($monthStart) ? $employmentStart : $monthStart;
            $workingDays = 0;
            for ($day = $periodStart->copy(); $day->lte($today); $day->addDay()) {
                if ($day->isWeekday()) {
                    $workingDays++;
                }
            }

            $row['workingDays'] = $workingDays;
            $row['presentDays'] = $presentDays;
            $row['lateDays'] = $lateDays;
            $row['absentDays'] = max(0, $workingDays - $presentDays);
            $staff[$userId] = $row;
        }

        return [
            'staff' => $staff->sortBy(fn ($row) => mb_strtolower($row['fullName'] ?: $row['username']))->values(),
            'periodLabel' => $today->translatedFormat('F Y'),
        ];
    }

    public function productivityShow(Request $request, string $id)
    {
        $role = $request->session()->get('auth_user.role');
        $own = $request->session()->get('auth_user.id') === $id
            && $request->session()->get('auth_user.source') === 'user';
        abort_unless(in_array($role, ['ADMINISTRATOR', 'PIMPINAN'], true) || $own, 403);

        $data = $this->productivityData();
        $employee = $data['staff']->firstWhere('id', $id);
        abort_unless($employee, 404);
        $jobs = collect();
        foreach (['badan_hukum' => 'Badan Hukum/Usaha', 'non_badan_hukum' => 'Non Badan Hukum', 'ppat' => 'PPAT'] as $table => $label) {
            $jobs = $jobs->concat(DB::table($table)->where('staffId', $id)
                ->select('id', 'title', 'trackingCode', 'status', 'deadline', 'createdAt', 'updatedAt')
                ->orderByDesc('createdAt')->limit(10)->get()->map(function ($job) use ($table, $label) {
                    $job->jobType = $table;
                    $job->category = $label;
                    return $job;
                }));
        }
        $tasks = DB::table('job_employee_task as t')
            ->leftJoin('badan_hukum as bh', 'bh.id', '=', 't.badanHukumId')
            ->leftJoin('non_badan_hukum as nbh', 'nbh.id', '=', 't.nonBadanHukumId')
            ->leftJoin('ppat as p', 'p.id', '=', 't.ppatId')
            ->where('t.userId', $id)
            ->select('t.id', 't.taskType', 't.customTask', 't.createdAt')
            ->selectRaw('COALESCE(bh.title, nbh.title, p.title) as jobTitle')
            ->orderByDesc('t.createdAt')->limit(10)->get();
        $profile = DB::table('staff')->where('userId', $id)->first();
        $attendance = $profile ? DB::table('attendance')->where('staffId', $profile->id)
            ->whereBetween('date', [now()->startOfMonth(), now()->endOfDay()])
            ->select('date', 'checkIn', 'checkOut')->orderByDesc('date')->get() : collect();

        return Inertia::render('Modules/ProductivityDetail', [
            'employee' => $employee,
            'periodLabel' => $data['periodLabel'],
            'jobs' => $jobs->sortByDesc('createdAt')->take(10)->values(),
            'tasks' => $tasks,
            'attendance' => $attendance,
        ]);
    }

    public function deeds(Request $request)
    {
        $query = $this->jobs($request);

        return Inertia::render('Modules/Deeds', [
            'jobs' => (clone $query)->paginate(30)->withQueryString(),
            'totalAkta' => (clone $query)->count(),
            'staff' => DB::table('user')->select('id', 'fullName')->orderBy('fullName')->get(),
            'filters' => $request->only('from', 'to', 'staff', 'witness'),
        ]);
    }

    public function witnesses(Request $request)
    {
        $rows = $this->jobs($request)->whereNotNull('saksi')->where('saksi', '<>', '')->get();
        $grouped = collect();
        foreach ($rows as $job) {
            foreach (array_filter(array_map('trim', explode(',', $job->saksi))) as $name) {
                $grouped->push(['name' => $name, 'job' => $job]);
            }
        }

        return Inertia::render('Modules/Witnesses', ['rows' => $grouped->sortBy('name')->values(), 'search' => (string) $request->query('search')]);
    }

    private function jobs(Request $request)
    {
        $parts = collect(['badan_hukum' => 'Badan Hukum/Usaha', 'non_badan_hukum' => 'Non Badan Hukum', 'ppat' => 'PPAT'])->map(fn ($category, $table) => DB::table($table.' as j')->leftJoin('client as c', 'c.id', '=', 'j.clientId')->leftJoin('user as u', 'u.id', '=', 'j.staffId')->select('j.id', 'j.trackingCode', 'j.title', 'j.status', 'j.invoiceStatus', 'j.saksi', 'j.createdAt', 'j.staffId', 'c.name as clientName', 'u.fullName as staffName')->selectRaw('? as category, ? as jobType', [$category, $table]));
        $union = $parts->shift();
        foreach ($parts as $part) {
            $union->unionAll($part);
        }$q = DB::query()->fromSub($union, 'jobs')->orderByDesc('createdAt');

        return $q->when($request->query('from'), fn ($x, $v) => $x->whereDate('createdAt', '>=', $v))->when($request->query('to'), fn ($x, $v) => $x->whereDate('createdAt', '<=', $v))->when($request->query('staff'), fn ($x, $v) => $x->where('staffId', $v))->when($request->query('witness'), fn ($x, $v) => $x->where('saksi', 'like', "%{$v}%"))->when($request->query('search'), fn ($x, $v) => $x->where(fn ($x) => $x->where('saksi', 'like', "%{$v}%")->orWhere('trackingCode', 'like', "%{$v}%")));
    }
}
